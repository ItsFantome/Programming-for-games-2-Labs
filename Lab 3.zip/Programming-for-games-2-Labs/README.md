# Programming-for-games-2-Labs

I will be making a 3D platformer where the player will go around a cyberpunk level to collect key objects and defeat enemies. I'm looking to make something like a 3D beat em up type game. You will play as a robot bounty hunter who's completing various bounties and tasks.

I will be using this free asset pack off of quaternius.
https://quaternius.com/packs/cyberpunkgamekit.html
